# !/usr/bin/env python3
import json
from settings import config, logger


def set_session_uri(uri):
    config.set('CBOT', 'uri', uri)
    with open('config.ini', 'w') as configfile:
        config.write(configfile)


def get_locale_str(locale, strid):
    with open('locale/'+locale+'.json') as json_file:
        json_data = json.load(json_file)
        return json_data[strid]
    return None


