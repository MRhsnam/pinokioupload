# !/usr/bin/env python3
import subprocess, requests, json
from settings import config, logger

def confirm_session_uri(uri):
    try:
        print('confirm_session_uri')
        _url = config.get('SERVER', 'HTTP_SERVER_URL') + '/api/chat/' + uri +'/'
        res = requests.get(url= _url)
        res.raise_for_status()
        return True
    except Exception as e:
        print('confirm_session_uri', uri, e)
        return False


def create_session_uri(user_id, chatbot_id):
    try:
        print('create_session_uri')
        _url = config.get('SERVER', 'HTTP_SERVER_URL') + '/api/chat/'
        _data = {'user_id':user_id, 'chatbot_id':chatbot_id}
        res = requests.post(url= _url, data=_data)
        res.raise_for_status()
        _json = json.loads(res.text)
        return _json['uri']
    except Exception as e:
        print('create_session_uri', e)
        return None


def get_init_message(uri, user_id):
    try:
        print('get_init_message')
        _url = config.get('SERVER', 'HTTP_SERVER_URL') + '/api/chat/' + uri + '/client/message/' + user_id
        res = requests.get(_url)
        res.raise_for_status()
        _json = json.loads(res.text)
        return _json
    except Exception as e:
        print('get_init_message', e)
        return None


def request_chat_message(uri, user_id, context, qry_text):
    try:
        _url = config.get('SERVER', 'HTTP_SERVER_URL') + '/api/chat/' + uri + '/client/message/' + user_id
        _data = {
            'user_id': user_id,
            'statement': {
                'context': context,
                'input': {
                    'text': qry_text
                }
            }
        }
        res = requests.post(_url, json=_data)
        res.raise_for_status()
        _json = json.loads(res.text)
        return _json
    except Exception as e:
        print('request_chat_message', e)
        return None


def authenticate_user_id(user_id):
    try:
        _url = config.get('SERVER', 'HTTP_SERVER_URL') + '/api/user/' + user_id
        res = requests.get(url= _url)
        res.raise_for_status()
        return True
    except Exception as e:
        print('authenticate_user_id', e)
        return False


def tracking_location(user_id):
    try:
        _url = config.get('SERVER', 'HTTP_SERVER_URL') + '/api/location/'
        res = requests.post(url= _url, data={'user':user_id})
        res.raise_for_status()
        return True
    except Exception as e:
        print('tracking_location', e)
        return False


def update_alarm(user_id, aplayer):
    _url = config.get('SERVER', 'HTTP_SERVER_URL') + '/api/alarms/' + user_id
    res = requests.get(url= _url)

    if res.status_code == requests.codes.ok:
        _alarms = json.loads(res.text)
        print ('update_alarm')

        wf = open(config.get('PATH', 'db_alarms') , 'w')

        for _alarm in _alarms:
            if _alarm['is_enable']:
                times = _alarm['time'].split(':')
                min = str(int(times[1]))
                hour = str(int(times[0]))
                weekdays = _alarm['weekdays']

                aplayer.make_alarm_guide(_alarm['id'], _alarm['title'])

                wf.write('\t'.join((min, hour, weekdays, str(_alarm['id']))) + '\n')

        wf.close()


    return None

