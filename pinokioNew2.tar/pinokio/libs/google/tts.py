
def tts(query_text, language, tmp_path):
    import os
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/home/pi/pinokio/libs/google/aicapsule.json"

    """Synthesizes speech from the input string of text."""
    from google.cloud import texttospeech
    client = texttospeech.TextToSpeechClient()

    input_text = texttospeech.SynthesisInput(text=query_text)

    voiceId = None
    if language == 'ko-KR':
        voiceId = 'ko-KR-Standard-A'

    #ko-KR-Wavenet-A =>women
    #ko-KR-wavenet-D =>men

    # Note: the voice can also be specified by name.
    # Names of voices can be retrieved with client.list_voices().
    voice = texttospeech.VoiceSelectionParams(
        language_code=language,
        name=voiceId
    )

    audio_config = texttospeech.AudioConfig(
        audio_encoding=texttospeech.AudioEncoding.LINEAR16,
    #    pitch=-5.0,
    #    speaking_rate=0.8,
        sample_rate_hertz=16000,
        volume_gain_db = 10
    )
    #audio_config = texttospeech.AudioConfig(
    #    audio_encoding=texttospeech.AudioEncoding.MP3
    #)

    response = client.synthesize_speech(input=input_text, voice=voice, audio_config=audio_config)

    #response = client.synthesize_speech(input_text, voice, audio_config)

    with open(tmp_path, 'wb') as out:
        out.write(response.audio_content)



