# !/usr/bin/env python3
import websocket
from threading import Thread
from time import sleep
import json

# from libs.aiy.board import Led
#import libs.aiy.voicehat

from settings import config, State, Guide
from modules.server_request import (
    confirm_session_uri,
    update_alarm,
)

class ChatbotWSManager:

    def __init__(self, sys_info, aplayer):

        # info
        self.sys_info = sys_info
        self.language_code = config.get('CBOT', 'language_code')
        self.uri = config.get('CBOT', 'uri')

        # module
        #self.board = board
        self.aplayer = aplayer

        #self.led = libs.aiy.voicehat.get_led()


    def run(self):

        def on_message(ws, message):
            print ('on_message', message)
            try:
                _json = json.loads(message)
                if _json['type'] == 'chat':
                    source_id = _json['user']['id']
                    source_type = _json['source_type']

                    # if source_id != int(self.sys_info['user_id']) and source_id != -1:
                    if source_type == 'W':
                        message_text = _json['message']
                        if message_text != '':
                            # self.board.led.state = Led.BLINK
                            #self.led.set_state(libs.aiy.voicehat.LED.BLINK)
                            self.aplayer.play_tts(message_text)
                            print('message txt : ', message_text)
                            #self.led.set_state(libs.aiy.voicehat.LED.OFF)

                elif _json['type'] == 'update_alarm':
                    update_alarm(self.sys_info['user_id'], self.aplayer)

            except Exception as e:
                print('socket on_message error', e)


        def on_error(ws, error):
            print ('on_error', error)
            pass

        def on_close(ws):
            # print ('on_close')
            sleep(1.0)

        def on_open(ws):
            # print ('on_open')
            pass

        while(True):
            if self.sys_info['state'] == State.CHAT:
                if self.uri == 'null' or not confirm_session_uri(self.uri):
                    self.uri = config.get('CBOT', 'uri')
                    continue

                try:
                    # websocket.enableTrace(True)
                    ws_url = config.get('SERVER', 'WS_SERVER_URL') + "/" + self.uri
                    ws = websocket.WebSocketApp(ws_url,
                                                on_open=on_open,
                                                on_message=on_message,
                                                on_error=on_error,
                                                on_close=on_close)
                    ws.run_forever()
                except Exception as e:
                    print('socket connection error', e)
                    sleep(1.0)
                    continue


