import subprocess

from settings import config, Guide


class ServiceManager:

    def __init__(self, _aplayer):
      #  self.board = _board
        self.aplayer = _aplayer


    def play_media(self, _text, _url):
        self.aplayer.play_tts(_text)
        self.aplayer.play_media(_url)
        return None

    def play_success(self, _text):
        self.aplayer.play_success()
        self.aplayer.play_tts_bg(_text)
        return None

    def play_fail(self, _text):
        self.aplayer.play_fail()
        self.aplayer.play_tts_bg(_text)
        return None

    def stop_media(self, _text):
        self.aplayer.play_tts(_text)
        self.aplayer.kill_media()
        return None

    def ctrl_volume(self, _text):

        def get_curr_vol():
            cmd = "amixer get Master | grep 'Front Left:'| awk '{ print $5 }'"
            val = subprocess.check_output(cmd, shell=True).replace('[','').replace('%]','')
            return int(val)

        def ctrl(volume):
            cmd = "amixer sset Master "+str(volume)+"%"
            subprocess.check_output(cmd, shell=True)

        if _text == 'mute':
            vol = 0
            ctrl(vol)

        elif _text == 'up':
            vol = get_curr_vol() + 5
            if vol > 100:
                vol = 100
            ctrl(vol)

        elif _text == 'down':
            vol = get_curr_vol() - 5
            if vol < 0:
                vol = 0
            ctrl(vol)

        elif _text.isdigit():
            vol = int(_text)
            ctrl(vol)

        return None
