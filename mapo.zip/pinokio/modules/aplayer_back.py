# !/usr/bin/env python3
import os, subprocess
import signal
from multiprocessing import Process
from threading import Thread

from settings import config, State, Guide
from modules.utils import get_locale_str
# from libs.amz.polly import polly
from libs.google.tts import tts
#import libs.aiy.voicehat

from time import sleep

class APlayer:

    def __init__(self):
        # self.led = libs.aiy.voicehat.get_led()
        # led.set_state(libs.aiy.voicehat.LED.BLINK)
        # led.set_state(libs.aiy.voicehat.LED.OFF)
        #cmd = "amixer -c 1 sset 'Playback_Path' HP_NO_MIC"
        #subprocess.check_output(cmd, shell=True)
        pass
    #def on_led(self):
        #with open('/sys/class/led/red', 'w') as file:
        #    file.write('255')
        #with open('/sys/class/led/green', 'w') as file:
        #    file.write('255')
        #with open('/sys/class/led/blue', 'w') as file:
        #    file.write('255')
        
    #def off_led(self):
        #with open('/sys/class/led/red', 'w') as file:
        #    file.write('0')
        #with open('/sys/class/led/green', 'w') as file:
        #    file.write('0')
        #with open('/sys/class/led/blue', 'w') as file:
        #    file.write('0')

    def make_guide(self, guide_type=None, lan=config.get('CBOT', 'LANGUAGE_CODE'), fpath='.voice/'):
        fpath = fpath + str(guide_type.value) + ".wav"
        text = get_locale_str(lan, guide_type.name)
        if text is not None:
            if not os.path.exists(fpath):
                tts(text, lan, fpath)

    def play_guide(self, guide_type=None, lan=config.get('CBOT', 'LANGUAGE_CODE'), fpath='.voice/'):
        fpath = fpath + str(guide_type.value) + ".wav"
        text = get_locale_str(lan, guide_type.name)
        if text is not None:
            if not os.path.exists(fpath):
                tts(text, lan, fpath)
            self.play_voice(fpath)

    def play_react(self, fpath='/home/pi/pinokio/media/react.mp3'):
        self.kill_media()
        self.kill_voice()
        cmd = 'mpg321 '+fpath
        subprocess.check_output(cmd, shell=True)
        # os.system(cmd)
        # subprocess.call(cmd)

    def play_success(self, fpath='/home/pi/pinokio/media/success.mp3'):
        self.kill_media()
        self.kill_voice()
        cmd = 'mpg321 '+fpath
        subprocess.check_output(cmd, shell=True)

    def play_fail(self, fpath='/home/pi/pinokio/media/fail.mp3'):
        self.kill_media()
        self.kill_voice()
        cmd = 'mpg321 ' + fpath
        subprocess.check_output(cmd, shell=True)

    def make_alarm_guide(self, id, text, lan=config.get('CBOT', 'LANGUAGE_CODE'), fpath='.voice/'):
        fpath = fpath + "alarm_"+str(id) + ".wav"
        if text is not None:
            # if not os.path.exists(fpath):
            text = get_locale_str(lan, Guide.ALARM.name) % (text)
            tts(text, lan, fpath)

    def play_tts(self, text, lan=config.get('CBOT', 'LANGUAGE_CODE'), fpath='.voice/tts.wav'):
        if text is not None and text != '':
            tts(text, lan, fpath)
            self.play_voice(fpath)

    def play_tts_bg(self, text, lan=config.get('CBOT', 'LANGUAGE_CODE'), fpath='.voice/tts.wav'):
        self.kill_voice()
        if text is not None and text != '':
            def _run():
                #self.led.set_state(libs.aiy.voicehat.LED.BLINK)
                tts(text, lan, fpath)
                cmd = 'aplay --format=S16_LE --rate=16000 ' + fpath
                subprocess.check_output(cmd, shell=True)
                #self.led.set_state(libs.aiy.voicehat.LED.OFF)
            th1 = Thread(target=_run)
            th1.start()
            # os.system(cmd)

    # media
    def get_media_pids(self):
        cmd = "ps -ef | awk '{ print $2, $8 }'| grep mpg321 | awk '{ print $1 }'"
        returned_value = subprocess.check_output(cmd, shell=True)
        tmp_pids = returned_value.decode("utf-8").split('\n')
        pids = []
        for pid in tmp_pids:
            if pid.isdigit():
                pids.append(pid.strip())
        return pids

    def play_media(self, url_stream):
        self.kill_media()
        self.kill_voice()
        cmd = 'mpg321 ' + url_stream
        def run(cmd):
            os.system(cmd)

        th1 = Thread(target=run, args=(cmd, ))
        th1.start()
        # os.system(cmd)

    def pause_media(self):
        pids = self.get_media_pids()
        for pid in pids:
            try:
                os.kill(int(pid), signal.SIGSTOP)
            except:
                pass

    def resume_media(self):
        pids = self.get_media_pids()
        for pid in pids:
            try:
                os.kill(int(pid), signal.SIGCONT)
            except:
                pass

    def kill_media(self):
        pids = self.get_media_pids()
        kill_count = 0
        for pid in pids:
            try:
                os.kill(int(pid), signal.SIGKILL)
                kill_count += 1
            except:
                pass
        return kill_count


    # voice
    def get_voice_pids(self):
        cmd = "ps -ef | awk '{ print $2, $8 }'| grep aplay | awk '{ print $1 }'"
        returned_value = subprocess.check_output(cmd, shell=True)
        tmp_pids = returned_value.decode("utf-8").split('\n')
        pids = []
        for pid in tmp_pids:
            if pid.isdigit():
                pids.append(pid)
        return pids

    def play_voice(self, fpath=None):
        self.kill_voice()
        cmd = 'aplay --format=S16_LE --rate=16000 '+fpath
        subprocess.check_output(cmd, shell=True)

    def kill_voice(self):
        pids = self.get_voice_pids()
        for pid in pids:
            try:
                os.kill(int(pid), signal.SIGKILL)
            except:
                pass
