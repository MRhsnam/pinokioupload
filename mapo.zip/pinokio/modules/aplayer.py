﻿# !/usr/bin/env python3
import os, subprocess
import signal
from multiprocessing import Process
from threading import Thread

from settings import config, State, Guide
from modules.utils import get_locale_str
#from libs.amz.polly import polly
from libs.google.tts import tts

from time import sleep

class APlayer:

    def __init__(self):
        cmd = 'amixer -c 1 sset '"'Playback Path'"' HP_NO_MIC'
        pass
        

    def make_guide(self, guide_type=None, lan=config.get('CBOT', 'LANGUAGE_CODE'), fpath='.voice/'):
        fpath = fpath + str(guide_type.value) + ".wav"
        text = get_locale_str(lan, guide_type.name)
        if text is not None:
            if not os.path.exists(fpath):
                tts(text, lan, fpath)

    def play_guide(self, guide_type=None, lan=config.get('CBOT', 'LANGUAGE_CODE'), fpath='.voice/'):
        fpath = fpath + str(guide_type.value) + ".wav"
        text = get_locale_str(lan, guide_type.name)
        if text is not None:
            if not os.path.exists(fpath):
                tts(text, lan, fpath)
            self.play_voice(fpath)

    def make_alarm_guide(self, id, text, lan=config.get('CBOT', 'LANGUAGE_CODE'), fpath='.voice/'):
        fpath = fpath + "alarm_"+str(id) + ".wav"
        if text is not None:
            # if not os.path.exists(fpath):
            text = get_locale_str(lan, Guide.ALARM.name) % (text)
            tts(text, lan, fpath)

    def play_tts(self, text, lan=config.get('CBOT', 'LANGUAGE_CODE'), fpath='.voice/tts.wav'):
        if text is not None and text != '':
            tts(text, lan, fpath)
            self.play_voice(fpath)

    # media
    def get_media_pids(self):
        cmd = "ps -ef | awk '{ print $2, $8 }'| grep mpg321 | awk '{ print $1 }'"
        returned_value = subprocess.check_output(cmd, shell=True)
        tmp_pids = returned_value.decode("utf-8").split('\n')
        pids = []
        for pid in tmp_pids:
            if pid.isdigit():
                pids.append(pid.strip())
        return pids

    def play_media(self, url_stream):
        self.kill_media()
        self.kill_voice()
        cmd = 'mpg321 ' + url_stream
        def run(cmd):
            os.system(cmd)

        th1 = Thread(target=run, args=(cmd, ))
        th1.start()
        # os.system(cmd)

    def pause_media(self):
        pids = self.get_media_pids()
        for pid in pids:
            try:
                os.kill(int(pid), signal.SIGSTOP)
            except:
                pass

    def resume_media(self):
        pids = self.get_media_pids()
        for pid in pids:
            try:
                os.kill(int(pid), signal.SIGCONT)
            except:
                pass

    def kill_media(self):
        pids = self.get_media_pids()
        kill_count = 0
        for pid in pids:
            try:
                os.kill(int(pid), signal.SIGKILL)
                kill_count += 1
            except:
                pass
        return kill_count


    # voice
    def get_voice_pids(self):
        cmd = "ps -ef | awk '{ print $2, $8 }'| grep aplay | awk '{ print $1 }'"
        returned_value = subprocess.check_output(cmd, shell=True)
        tmp_pids = returned_value.decode("utf-8").split('\n')
        pids = []
        for pid in tmp_pids:
            if pid.isdigit():
                pids.append(pid)
        return pids

    def play_voice(self, fpath=None):
        self.kill_voice()
        cmd = 'aplay --format=S16_LE --rate=16000 '+fpath
        subprocess.check_output(cmd, shell=True)

    def kill_voice(self):
        pids = self.get_voice_pids()
        for pid in pids:
            try:
                os.kill(int(pid), signal.SIGKILL)
            except:
                pass
