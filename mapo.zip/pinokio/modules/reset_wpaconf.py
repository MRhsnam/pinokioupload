#!/usr/bin/python3
import subprocess

try:
    cmd = "cat .tmp/wpa_supplicant.conf > /etc/wpa_supplicant/wpa_supplicant.conf"
    print ('cmd', cmd)
    subprocess.check_output(cmd, shell=True)
except:
    print ('Fail')

print ('OK')







