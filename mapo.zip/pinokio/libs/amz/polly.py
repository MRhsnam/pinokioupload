
from boto3 import client

def polly(text, language, tmp_path):
    polly = client("polly", region_name="ap-northeast-2")

    voiceId = None
    if language == 'ko-KR':
        voiceId = 'Seoyeon'

    response = polly.synthesize_speech(
        Text=text,
        OutputFormat="pcm",
        TextType='text',
        VoiceId=voiceId)

    stream = response.get("AudioStream")

    with open(tmp_path, 'wb') as f:
        data = stream.read()
        f.write(data)