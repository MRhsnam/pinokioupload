#!/usr/bin/python3


# !/usr/bin/env python3
from time import sleep
import json
import datetime
from pytz import timezone

# from libs.aiy.board import Led
#import libs.aiy.voicehat

from settings import config, State, Guide

import sys, os, subprocess

class AlarmManager:

    def __init__(self, sys_info, aplayer):

        # info
        self.sys_info = sys_info
        self.language_code = config.get('CBOT', 'language_code')
        self.uri = config.get('CBOT', 'uri')

        # module
        #self.board = board
        self.aplayer = aplayer

        #self.led = libs.aiy.voicehat.get_led()


    def run(self):

        pre_min = -1
        while True:
            sleep(10)

            now = datetime.datetime.now(timezone('Asia/Seoul'))

            # print ('now', now)

            if pre_min == now.minute:
                continue
                
            pre_min = now.minute

            rf = open(config.get('PATH', 'db_alarms'), 'r')
            lines = rf.readlines()
            for line in lines:
                arr = line.split('\t')
                min = arr[0]
                hour = arr[1]
                weekdays = arr[2]
                alarm_id = arr[3].replace('\n','')

                if (min == str(now.minute)) and (hour == str(now.hour)) and (str((now.weekday()+1)%7) in weekdays):
                    #self.led.set_state(libs.aiy.voicehat.LED.BLINK)
                    # self.board.led.state = Led.BLINK
                    cmd = 'mpg321 /home/pi/pinokio/media/alarm.mp3'
                    subprocess.check_output(cmd, shell=True)

                    self.aplayer.play_voice('.voice/alarm_'+alarm_id+'.pcm')
                    # self.board.led.state = Led.OFF
                    #self.led.set_state(libs.aiy.voicehat.LED.OFF)

            rf.close()





#
