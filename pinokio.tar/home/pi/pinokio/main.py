#!/usr/bin/env python3

from multiprocessing import Process, Manager
from threading import Thread

from auth import AuthManager
from chatbot import ChatbotManager
from chatbot_ws import ChatbotWSManager
from alarm import AlarmManager
from modules.aplayer import APlayer
from settings import config, State

from libs.aiy.board import Board, Led
import libs.aiy.voicehat
import time


def main():

    # initialize
    manager = Manager()
    sys_info = manager.dict()
    sys_info['state'] = State.READY
    sys_info['user_id'] = config.get('USER', 'user_id')
    sys_info['uri'] = config.get('CBOT', 'uri')
    sys_info['chatbot_id'] = config.get('CBOT', 'chatbot_id')


    led = libs.aiy.voicehat.get_led()
    led.set_state(libs.aiy.voicehat.LED.OFF)
    # board.led.state = Led.OFF
    
    board = Board()
    aplayer = APlayer()

    auth_manager = AuthManager(sys_info, board, aplayer)
    proc_auth = Thread(target=auth_manager.run)
    proc_auth.start()

    cbot_manager = ChatbotManager(sys_info, board, aplayer)
    proc_cbot = Thread(target=cbot_manager.run)
    proc_cbot.start()

    cbot_ws_manager = ChatbotWSManager(sys_info, board, aplayer)
    proc_cbot_ws = Thread(target=cbot_ws_manager.run)
    proc_cbot_ws.start()

    alarm_manager = AlarmManager(sys_info, board, aplayer)
    proc_alarm = Thread(target=alarm_manager.run)
    proc_alarm.start()

    proc_auth.join()
    proc_cbot.join()
    proc_cbot_ws.join()
    proc_alarm.join()

if __name__ == '__main__':
    main()
