# !/usr/bin/env python3
import requests
import os
import bluetooth

from multiprocessing import Process
from threading import Thread

from wireless import Wireless
from time import sleep
import time, json
import subprocess

from settings import config, State, Guide
from modules.server_request import authenticate_user_id, tracking_location, update_alarm


class AuthManager:

    def __init__(self, sys_info, board, aplayer):

        # info
        self.sys_info = sys_info
        self.proc_auth = None
        self.is_user_id_authenticated = False
        self.curr_wireless = None

        # module
        self.board = board
        self.aplayer = aplayer


    # check saved network information on system
    def is_initialized_network_info(self):
        try:
            cmd = "cat /etc/wpa_supplicant/wpa_supplicant.conf | grep network= |wc -l"
            return_val = subprocess.check_output(cmd, shell=True).decode("utf-8").replace('\n', '')
            if int(return_val) > 0:
                return True
        except:
            pass
        return False

    def auth(self):

        self.is_bt_connected = False

        def get_mac_address():
            cmd = 'hcitool dev | grep -o "[[:xdigit:]:]\{11,17\}"'
            mac_address = subprocess.check_output(cmd, shell=True).decode("utf-8").replace('\n', '')
            return mac_address

        def set_wpa_config(data):
            f = open(".tmp/wpa_supplicant.conf", 'w')
            f.write(data)
            f.close()

            cmd = 'sudo python3 modules/reset_wpaconf.py'
            rst = subprocess.check_output(cmd, shell=True).decode("utf-8").replace('\n', '')
            print (rst)
            if 'OK' in rst:
                return True
            return False

        def restart_wireless():
            cmd = 'sudo wpa_cli -i wlan0 reconfigure'
            rst = subprocess.check_output(cmd, shell=True).decode("utf-8").replace('\n', '')
            if 'OK' in rst:
                return True
            return False

        def get_response(res_type, rst):
            response = {
                'res_type': res_type,
                'rst': rst
            }
            return response

        def set_user_id(user_id):
            config.set('USER', 'user_id', user_id)
            with open('config.ini', 'w') as configfile:
                config.write(configfile)
            self.sys_info['user_id'] = config.get('USER', 'user_id')
            self.is_authenticated = False

        def pauth():
            print ("start bt pauth")

            if not self.is_initialized_network_info():
                self.aplayer.play_guide(Guide.INIT_WIRELESS)
            else:
                self.aplayer.play_guide(Guide.SET_WIRELESS)

            s = bluetooth.BluetoothSocket(bluetooth.RFCOMM)
            # s.bind(("", bluetooth.PORT_ANY))
            s.bind((get_mac_address(), 1))
            s.listen(1)

            size = 1024
            try:
                client, clientInfo = s.accept()
                self.is_bt_connected = True
                print ("bt accept client")
                while 1:
                    data = client.recv(size)
                    client.send(json.dumps(get_response('BT_CONNECTED', 'OK'), ensure_ascii=False))
                    rst_restart = False
                    if data:
                        _json = json.loads(data.decode("utf-8"))
                        print ("recv data", _json)

                        # user_id = _json['user_id']
                        user_id = _json['token']
                        wifis = _json['wifiList']

                        set_user_id(user_id)
                        print ("set_user_id", user_id)

                        if len(wifis) > 0:

                            data = 'ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev' + '\n'
                            data += 'update_config=1' + '\n'
                            data += 'country=US' + '\n\n'

                            for idx, wifi in enumerate(wifis, 1):
                                data += 'network={' + '\n'
                                data += '   ssid="' + wifi['ssid'] + '"' + '\n'
                                data += '   psk="' + wifi['password'] + '"' + '\n'
                                data += '   priority=' + str(idx) + '\n'
                                data += '}' + '\n\n'

                            rst = set_wpa_config(data)
                            print ("set_wpa_config", rst)
                            if rst:
                                self.aplayer.play_guide(Guide.PROCESSING_SET_WIRELESS)
                                rst_restart = restart_wireless()
                                print ("restart_wireless", rst_restart)

                    if not rst_restart :
                        self.aplayer.play_guide(Guide.FAIL_SET_WIRELESS)
                        client.send(json.dumps(get_response('RESULT', rst_restart), ensure_ascii=False))
                    else:
                        self.aplayer.play_guide(Guide.SUCCESS_SET_WIRELESS)
                        client.send(json.dumps(get_response('RESULT', rst_restart), ensure_ascii=False))
                        break

            except Exception as e:
                print ('Closing socket, Exception', e)
                self.is_bt_connected = False
                client.close()
                s.close()

        # after 30, check bt connection, terminate process
        def check_bt_connected():
            sleep(180.0)
            if self.proc_auth.is_alive() and not self.is_bt_connected:
                self.aplayer.play_guide(Guide.TERMINATE_WIRELESS)
                self.proc_auth.terminate()

        # running auth process on bluetooth
        if self.proc_auth is None or not self.proc_auth.is_alive():
            self.proc_auth = Process(target=pauth)
            self.proc_auth.start()

            # bt connection monitoring
            th = Thread(target=check_bt_connected)
            th.start()
            th.join()

    def run(self):

        def check_button():
            while True:
                self.board.button.wait_for_press()
                start_pushing_time = time.time()
                self.board.button.wait_for_release()
                pushing_time = time.time() - start_pushing_time
                # more 5sec -> go to auth mode
                if pushing_time >= 5.0:
                    self.auth()

        def check_wireless():
            wireless = Wireless()
            while True:
                _wireless = wireless.current()
                if _wireless is not None:  # network connected

                    # check authenticated user_id
                    if not self.is_user_id_authenticated:
                        self.is_user_id_authenticated = authenticate_user_id(self.sys_info['user_id'])
                        # FIX ME
                        # no server auth, but try auth forever
                        continue

                    # check changed wireless info
                    if self.curr_wireless != _wireless:
                        self.curr_wireless = _wireless
                        # if tracking_location(self.sys_info['user_id']):
                        #     self.curr_wireless = _wireless

                    # change state from READY to CHAT
                    if self.sys_info['state'] != State.CHAT:
                        self.sys_info['state'] = State.CHAT
                        update_alarm(self.sys_info['user_id'], self.aplayer)
                        # tracking_location(self.sys_info['user_id'])

                else:  # network disconnected

                    # change state from CHAT to READY
                    if self.sys_info['state'] != State.READY:
                        self.sys_info['state'] = State.READY
                        # self.aplayer.play_guide(Guide.SET_STATE_READY)

                    # setting network info
                    if not self.is_initialized_network_info():
                        # have no saved network info -> go to auth mode
                        # self.auth()
                        pass

                sleep(1.0)

        # th1 = Thread(target=check_button)
        # th1.start()

        th2 = Thread(target=check_wireless)
        th2.start()

        # th1.join()
        th2.join()



