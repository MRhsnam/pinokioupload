# !/usr/bin/env python3
# import websocket
from threading import Thread
from time import sleep
import time
import requests, json

# from libs.aiy.board import Led
from libs.aiy.cloudspeech import CloudSpeechClient
import libs.aiy.voicehat

from modules.service import ServiceManager
from settings import config, State, Guide
from modules.server_request import (
    confirm_session_uri,
    create_session_uri,
    get_init_message,
    request_chat_message,
)
from modules.utils import set_session_uri


class ChatbotManager:

    def __init__(self, sys_info, board, aplayer):

        # init google api
        self.cloudspeech = CloudSpeechClient()

        # info
        self.sys_info = sys_info
        self.context = None
        self.language_code = config.get('CBOT', 'language_code')
        self.uri = config.get('CBOT', 'uri')

        # module
        self.board = board
        self.aplayer = aplayer

        # self.led = libs.aiy.voicehat.get_led()


    def run(self):

        led = libs.aiy.voicehat.get_led()

        service_manager = ServiceManager(self.board, self.aplayer)

        def parse_message(_json):
            try:
                self.context = _json['statement']['context']
                _text = _json['statement']['output']['text']

                if 'cmds' in _json['statement']['output']:
                    cmds = _json['statement']['output']['cmds']
                    for cmd in cmds:
                        if cmd == 'volume':
                            _text = service_manager.ctrl_volume(_text)
                        elif cmd == 'song':
                            _url = _json['statement']['output']['url']
                            _text = service_manager.play_media(_text, _url)
                        elif cmd == 'stop_media':
                            _text = service_manager.stop_media(_text)
                        elif cmd == 'success':
                            _text = service_manager.play_success(_text)
                        elif cmd == 'fail':
                            _text = service_manager.play_fail(_text)
                return _text
            except Exception as e:
                print (e)
                return None


        while True:
            if self.sys_info['state'] == State.CHAT:
                # led.set_state(libs.aiy.voicehat.LED.OFF)
                try:
                    # not initialized chat message
                    if self.context is None:
                        if self.uri == 'null' or not confirm_session_uri(self.uri):
                            self.uri = create_session_uri(self.sys_info['user_id'], self.sys_info['chatbot_id'])
                            set_session_uri(self.uri)
                        _text = parse_message(get_init_message(self.uri, self.sys_info['user_id']))
                        self.aplayer.play_tts_bg(_text)

                    # initialized chat message
                    else:
                        self.board.button.wait_for_press()
                        # self.board.led.state = Led.ON
                        # start_time = time.time()
                        self.board.button.wait_for_release()
                        # led.set_state(libs.aiy.voicehat.LED.ON)
                        # btn_pushing_time = time.time() - start_time
                        # if btn_pushing_time > 3.0:
                        #     self.board.led.state = Led.OFF
                        #     continue

                        # if playing media
                        #   - stop media
                        #   - continue

                        if self.aplayer.kill_media() > 0:
                            self.aplayer.play_guide(Guide.STOP_MEDIA)
                            continue

                        # self.aplayer.pause_media()
                        # self.aplayer.play_guide(Guide.REACT)
                        self.aplayer.play_react()
                        print(" ===> recognizing...")
                        qry_text = self.cloudspeech.recognize(language_code=self.language_code)
                        print(" ===> qry_text", qry_text)

                        # self.board.led.state = Led.BLINK
                        # led.set_state(libs.aiy.voicehat.LED.OFF)
                        _text =parse_message(request_chat_message(self.uri, self.sys_info['user_id'], self.context, qry_text))
                        self.aplayer.play_tts_bg(_text)

                        # def run():
                        #     led.set_state(libs.aiy.voicehat.LED.BLINK)
                        #
                        #     led.set_state(libs.aiy.voicehat.LED.OFF)
                        #
                        # th1 = Thread(target=run)
                        # th1.start()

                        # self.aplayer.resume_media()
                        # self.board.led.state = Led.OFF
                        # led.set_state(libs.aiy.voicehat.LED.OFF)

                except Exception as e:
                    print (e)
                    led.set_state(libs.aiy.voicehat.LED.OFF)
                    # self.board.led.state = Led.OFF
            else:
                sleep(1.0)