# Copyright 2017 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Drivers for shared functionality provided by the VoiceHat."""

import libs.aiy._drivers._led

# GPIO definitions (BCM)
_GPIO_LED = 25

# Import LED class to expose the LED constants.
LED = libs.aiy._drivers._led.LED

# Global variables. They are lazily initialized.
_voicehat_led = None


def get_led():
    """Returns a driver to control the VoiceHat LED light with various animations.

    led = aiy.voicehat.get_led()

    # You may set any LED animation:
    led.set_state(aiy.voicehat.LED.PULSE_QUICK)
    led.set_state(aiy.voicehat.LED.BLINK)

    # Or turn off the light but keep the driver running:
    led.set_state(aiy.voicehat.LED.OFF)
    """
    global _voicehat_led
    if not _voicehat_led:
        _voicehat_led = libs.aiy._drivers._led.LED(channel=_GPIO_LED)
        _voicehat_led.start()
    return _voicehat_led
