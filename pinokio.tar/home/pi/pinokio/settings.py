# -*- coding: utf-8 -*-

import logging

# create logger
logger = logging.getLogger('simple_example')
logger.setLevel(logging.DEBUG)

# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to ch
ch.setFormatter(formatter)

# add ch to logger
logger.addHandler(ch)


import enum
class State(enum.Enum):
    READY = 0
    CHAT = 1

class Guide(enum.Enum):
    CONNECTED = 0
    REACT = 1
    INIT_WIRELESS = 2
    SET_WIRELESS = 3
    PROCESSING_SET_WIRELESS = 4
    FAIL_SET_WIRELESS = 5
    SUCCESS_SET_WIRELESS = 6
    ALARM = 7
    TERMINATE_WIRELESS = 8
    SET_STATE_READY = 9
    STOP_MEDIA = 10

import configparser
config = configparser.ConfigParser()
config.read('config.ini')